 # Content-based-Recommender-System
The Content-based Recommendation works by finding similarities in the contents of movies
It uses tf-idf and cosine similarity for N Most Similar Items from a dataset 
