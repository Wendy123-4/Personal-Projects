
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:summative/controllers/Auth.dart';
import 'package:summative/controllers/Constants.dart';
import 'package:google_fonts/google_fonts.dart';

import '../HomePage.dart';

// void main => runApp(HomePage());

final db = Firestore.instance ;


class HistoryScreen extends StatefulWidget {
  @override
  _HistoryScreenState createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  @override
  void initState() {
    getuser();

    super.initState();
  }
  var AmountPayable;

  String documentID = useRef.document().documentID;
  getuser() async{
    var firebaseUser = await FirebaseAuth.instance.currentUser();
    documentID = firebaseUser.uid;
    final DocumentSnapshot doc = await useRef.document(documentID).get();
    setState(() {
      AmountPayable = double.parse(doc.data['AmountPayable'].toString());

    });

  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: kPrimaryColor,
        leading: new IconButton(
          icon: new Icon(Icons.arrow_back, color: Colors.white,),
          onPressed: () {
            int count = 0;
            Navigator.of(context).popUntil((_) => count++ >= 2);
          },
        ),
        centerTitle: true, // this is all you ne
        title: Text(" Transaction History"),
      ),
      body: Column(
        children: [
          Expanded(
              child: StreamBuilder(
                  stream: Firestore.instance.collection('Videos').snapshots(),
                  builder:
                      (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
                    if (!snapshot.hasData) {
                      return Center(
                        child: CircularProgressIndicator(),
                      );
                    }

                    return ListView(
                      children: snapshot.data.documents.map((document) {
                        var url = document['Payments'];

                        return Center(
                          child: Container(
                            width: MediaQuery.of(context).size.width / 1.2,
                            child: Column(
                              children: <Widget>[
                                Padding(
                                  padding: EdgeInsets.only(top: 20, bottom: 5,),
                                  child: Text("Payments: ${AmountPayable== null ? '0':url.toString()}",
                                      style: GoogleFonts.quicksand(
                                          fontStyle: FontStyle.normal)),
                                ),
                              ],
                            ),
                          ),
                        );
                      }).toList(),
                    );
                  }),
              // StreamBuilder(
              //   stream: Firestore.instance.collection("users").document(documentID).snapshots(),
              //   builder: (BuildContext context, snapshot){
              //     if(snapshot.hasData && snapshot.data.isEmpty)
              //       return Text ('no data');
              //     if(snapshot.connectionState == ConnectionState.waiting){
              //       return CircularProgressIndicator();
              //     }else{
              //       final list =snapshot.data;
              //       // DateFormat inputFormat = DateFormat("dd/MM/yyyy");
              //       // DateTime dates = inputFormat.parse(snapshot.data["Payments"][0]["date"].toString());
              //       // List<String> names = List.from(list['Payments']);
              //       return
              //         ListView.builder(
              //           itemBuilder: (context, index){
              //           return ListTile(
              //            title: Text( "Payments: ${AmountPayable== null ? '0':snapshot.data["Payments"][0]["amount"].toString()}"  ,
              //              // subtitle: Text( "Date: ${dates.day}/${dates.month}/${dates.year}" ) ,
              //
              //           ));
              //          },
              //        itemCount: 1 ,
              //        );
              //     }
              //   },
              // ),
          )
        ],
      ),
    );
  }
}



