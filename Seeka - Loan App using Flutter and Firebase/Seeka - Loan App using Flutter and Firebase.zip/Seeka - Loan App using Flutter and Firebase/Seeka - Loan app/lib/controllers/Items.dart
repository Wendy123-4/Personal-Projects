List items = [
  {
    "header": "Welcome to Seeka",
    "description":
    "Borrow money instantly without any hassle",
    "image": "assets/images/1.png"
  },
  {
    "header": "Build",
    "description":
    "Online chat which provides its users maximum functionality to simplify the search",
    "image": "assets/images/2.png"
  },
  {
    "header": "Launch",
    "description":
    "Online chat which provides its users maximum functionality to simplify the search",
    "image": "assets/images/3.png"
  },
  {
    "header": "Launch",
    "description":
    "Online chat which provides its users maximum functionality to simplify the search",
    "image": "assets/images/4.png"
  },
  {
    "header": "Launch",
    "description":
    "Online chat which provides its users maximum functionality to simplify the search",
    "image": "assets/images/mainlogo.png"
  },

];