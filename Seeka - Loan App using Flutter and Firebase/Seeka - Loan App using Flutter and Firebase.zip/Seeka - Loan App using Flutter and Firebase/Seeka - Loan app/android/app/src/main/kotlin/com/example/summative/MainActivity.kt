package com.example.summative

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
